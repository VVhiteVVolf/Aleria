# Owain Draig Avatare

Owain Draig ist ein charismatischer Frauenschwarm, Kavallier, hoher Ritter des Reiches und der oberste Würdenträger Cenyrs. Die drei neuen Reaktionssets vom 11. Oktober 2026 zeigen seine charmante, diplomatische und gebieterische Seite.

Sein vorhandenes [Referenzporträt](Referenzen/owain-draig-portraet.jpg) bestimmt die Figur: kupferrotes langes Haar, blaue Augen, gepflegter roter Bart, schwarz-goldene Rüstung mit goldenem Drachen, roter Schal und Burgkulisse im warmen Abendlicht. Das Ausgangsporträt stammt aus `Stammbäume/assets/images/portraits/haus-draig/owain-draig.jpg` und bleibt unverändert.

## Die drei Sets

| Set | Vollständiges Sheet | Einzelavatare |
| --- | --- | --- |
| 01 Charme und Kavaliersgesten | [9er-Sheet](Sheets/owain-draig-set-01-charme-und-kavaliersgesten.png) | [9 PNGs](Output/set-01/) |
| 02 Hof und Diplomatie | [9er-Sheet](Sheets/owain-draig-set-02-hof-und-diplomatie-v2.png) | [9 PNGs](Output/set-02/) |
| 03 Ritterliche Autorität | [9er-Sheet](Sheets/owain-draig-set-03-ritterliche-autoritaet.png) | [9 PNGs](Output/set-03/) |

**Set 01:** charmante Begrüßung, schmeichelndes Kompliment, flirtendes Augenzwinkern, schelmisches Zuflüstern, herzliches Lachen, galante Einladung, würdiger Dank, spielerische Herausforderung und aufrichtige Zuwendung.

**Set 02:** souveränes Erklären, nachdenkliches Abwägen, diplomatische Skepsis, aufmerksames Zuhören, vertraulicher Rat, feierliche Verkündung, Anerkennung, höfliche Ablehnung und geistreiche Erwiderung.

**Set 03:** entschlossener Befehl, Halt und Ruhe, strenge Mahnung, unbeirrbare Herausforderung, gerechter Zorn, mitreißender Ruf, ritterliches Ehrenwort, Last der Verantwortung und beruhigende Zuversicht.

Jedes Sheet misst 1254×1254 Pixel. Alle **27 Einzelavatare sind quadratische PNGs mit 418×418 Pixeln** und erhalten den dargestellten Hintergrund. Die Dateinummern `Bild01` bis `Bild09` folgen der Reihenfolge von oben links nach unten rechts, zeilenweise. Die fertigen Bilder enthalten keine Beschriftung oder Nummerierung.

## Prompts und Zerlegung

Die Bilder wurden mit dem integrierten `image_gen`-Werkzeug erstellt. Die vollständig verwendeten [Prompts und Auftragsdateien](Prompts/) enthalten Referenz, Thema und die neun jeweiligen Gesten. Beim Hof-Set wurden die Handschuhe anschließend an die beiden anderen Sets angeglichen; der Korrekturprompt ist ebenfalls gespeichert. Der erste Entwurf liegt getrennt unter `Sheets/Entwuerfe`.

Die Einzelbilder wurden mit den unveränderten Zuschneidemethoden des zentralen Avatar Splitter Pro V3 exportiert: 3×3, Lücke X/Y 0, Autocrop aus. [avatar-manifest.json](avatar-manifest.json) hält die verwendeten Sheets, Ausschnittkoordinaten, Emotionszuordnungen und Prüfsummen fest. Alle 27 Ausschnitte wurden auf Reihenfolge, Identität, sichtbare Gestik und Randreste angesehen.

Die Ordner unter `Verarbeitung` enthalten die Arbeitskopien und ihre Ausgaben. Für die weitere Nutzung gelten die geprüften Dateien unter `Output`; die vollständigen Master-Sheets bleiben unter `Sheets` erhalten.

Das Paket `Owain-Draig-27-Avatare.zip` enthält die 27 Einzelavatare, drei finalen Sheets, Referenz, Prompts und Zuordnungsdateien. Entwürfe und doppelte Arbeitskopien sind nicht Bestandteil des Pakets.
